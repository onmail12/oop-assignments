package org.tugas;

import org.tugas.tugas3.Main;

public class App {
    public String getGreeting() {
        return "Hello World!";
    }

    public static void main(String[] args) {
        Main.main();
    }
}
